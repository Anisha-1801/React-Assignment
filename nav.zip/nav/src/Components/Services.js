import React, { Component } from 'react'

class Services extends Component {
  render() {
    return (
      <div><h3>
        You Chose Services</h3></div>
    )
  }
}

export default Services